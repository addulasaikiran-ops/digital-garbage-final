# Digital Garbage Bin

A temporary file-drop website. The intended production behavior is:

**upload → private temporary URL → automatic permanent deletion after 1 hour**

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Production storage

The current UI intentionally runs in demo upload mode. For production, connect the upload action to an S3-compatible object store such as Cloudflare R2.

Recommended flow:

1. Browser asks your API for a presigned upload URL.
2. API creates a random object key and `expiresAt = now + 1 hour`.
3. Browser uploads directly to object storage.
4. API stores only metadata in PostgreSQL.
5. Download endpoint checks `expiresAt` before issuing a short-lived download URL.
6. Storage lifecycle rules delete objects after one hour.
7. A scheduled cleanup job removes expired database records.

Do not make the bucket public.

## Security checklist

- Random 128-bit+ upload IDs
- HTTPS only
- Rate limiting
- Maximum file size and per-user/IP quotas
- Optional malware scanning
- Never trust client-provided expiration timestamps
- Server-side expiration checks
- Object storage lifecycle deletion as a second enforcement layer
