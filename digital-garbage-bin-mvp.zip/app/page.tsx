"use client";

import { useRef, useState } from "react";

const MAX_FILES = 20;
const MAX_SIZE = 2 * 1024 * 1024 * 1024;

export default function Home() {
  const input = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [dragging, setDragging] = useState(false);
  const [uploaded, setUploaded] = useState(false);
  const [seconds, setSeconds] = useState(3600);

  const addFiles = (incoming: FileList | File[]) => {
    const next = [...files, ...Array.from(incoming)];
    const unique = next.filter((f, i, arr) =>
      arr.findIndex(x => x.name === f.name && x.size === f.size) === i
    );
    setFiles(unique.slice(0, MAX_FILES));
  };

  const remove = (index: number) => setFiles(files.filter((_, i) => i !== index));

  const upload = async () => {
    if (!files.length) return;
    // Demo mode: replace this with a presigned-upload request to your storage backend.
    setUploaded(true);
    setSeconds(3600);
  };

  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;

  return (
    <main className="page">
      <nav className="nav">
        <div className="logo"><span>🗑️</span> Garbage Bin</div>
        <div className="badge">AUTO-DELETES IN 1 HOUR</div>
      </nav>

      <section className="hero">
        <p className="eyebrow">TEMPORARY DIGITAL DROP</p>
        <h1>Drop your digital<br /><em>garbage.</em></h1>
        <p className="subtitle">
          Upload photos, videos, audio, documents, archives — anything you need to
          share temporarily. Everything disappears automatically after one hour.
        </p>

        {!uploaded ? (
          <>
            <div
              className={`dropzone ${dragging ? "dragging" : ""}`}
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => { e.preventDefault(); setDragging(false); addFiles(e.dataTransfer.files); }}
              onClick={() => input.current?.click()}
            >
              <div className="bin-icon">🗑️</div>
              <h2>Drop files here</h2>
              <p>or click to choose from your device</p>
              <button className="choose" type="button">Choose files</button>
              <input
                ref={input}
                hidden
                multiple
                type="file"
                onChange={(e) => e.target.files && addFiles(e.target.files)}
              />
              <small>Up to {MAX_FILES} files · Max 2 GB each</small>
            </div>

            {files.length > 0 && (
              <div className="file-panel">
                <div className="panel-head">
                  <strong>{files.length} file{files.length > 1 ? "s" : ""} ready</strong>
                  <span>{(files.reduce((a, f) => a + f.size, 0) / 1024 / 1024).toFixed(1)} MB</span>
                </div>
                {files.map((file, i) => (
                  <div className="file-row" key={`${file.name}-${file.size}`}>
                    <span className="file-type">{file.type?.split("/")[0] || "FILE"}</span>
                    <div className="file-info"><b>{file.name}</b><small>{(file.size / 1024 / 1024).toFixed(2)} MB</small></div>
                    <button onClick={(e) => { e.stopPropagation(); remove(i); }} aria-label="Remove file">×</button>
                  </div>
                ))}
                <button className="upload" onClick={upload}>Send to the bin →</button>
              </div>
            )}
          </>
        ) : (
          <div className="success">
            <div className="success-icon">✓</div>
            <p className="eyebrow">UPLOAD COMPLETE</p>
            <h2>Your files are in the bin.</h2>
            <div className="timer">{String(mins).padStart(2,"0")}:{String(secs).padStart(2,"0")}</div>
            <p>Remaining until permanent deletion</p>
            <button className="share" onClick={() => navigator.clipboard?.writeText(location.href)}>
              Copy temporary link
            </button>
            <button className="again" onClick={() => { setUploaded(false); setFiles([]); }}>Upload more</button>
          </div>
        )}
      </section>

      <section className="features">
        <div><b>01</b><h3>Upload anything</h3><p>Images, video, audio, PDFs, documents, ZIPs and more.</p></div>
        <div><b>02</b><h3>Share temporarily</h3><p>Get a private link without creating an account.</p></div>
        <div><b>03</b><h3>Gone in one hour</h3><p>Expired files are permanently removed from storage.</p></div>
      </section>

      <footer>Built for files you don't want to keep around.</footer>
    </main>
  );
}