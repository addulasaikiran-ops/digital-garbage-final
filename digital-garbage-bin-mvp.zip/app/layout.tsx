import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Garbage Bin — Temporary File Drop",
  description: "Upload files that automatically disappear after one hour."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}